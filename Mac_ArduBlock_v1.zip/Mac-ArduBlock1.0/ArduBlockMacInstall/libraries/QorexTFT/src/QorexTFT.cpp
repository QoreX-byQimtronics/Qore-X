#include "QorexTFT.h"
#include "Free_Fonts.h" 
#include <cstring>

#define MAX_IMAGE_WIDTH 240
TFT_eSPI tft = TFT_eSPI();
PNG png;

FT6336U ft6336u(21, 22, 19, 4);

uint16_t x, y, touched;
extern int16_t prevX = -1, prevY = -1; // To store the previous position
#define PEN_SIZE 6  // You can change to reduce the pen size while drawing
// int16_t startX = 0, startY = 0; // Coordinates of the initial touch
FT6336U_TouchPointType tp;      // Variable to store touch data
bool running = false;
unsigned long startTime = 0;
unsigned long elapsedTime = 0;
char timeString[9];
//======================================================================================
//---------------------------------Display----------------------------------------------
//======================================================================================
void initDisplay(int rotation, uint16_t fillColor) {
  tft.init();
  tft.setRotation(rotation);
  tft.fillScreen(fillColor);
}

void fillScreen( uint16_t color){
  tft.fillScreen(color);
}

void displayMessage(const char* message, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.setCursor(x, y);
  tft.println(message);
}

void displayMessageBold(const char* text, int size, int x, int y, uint32_t color){
  // Set the font to bold
  tft.setFreeFont(FSB9); // Set the bold font (FSSB9)

  tft.setTextSize(size);

  // Set text color 
  tft.setTextColor(color);

  // Set text cursor position
  tft.setCursor(x, y);

  // Print the text
  tft.print(text);

  // Reset font to default (non-bold)
  tft.setFreeFont(0);
}

void displayMessageItalic(const char* text, int size, int x, int y, uint32_t color){
  // Set the font to bold
  tft.setFreeFont(FSI9); // Set the bold font (FSSB9)

  tft.setTextSize(size);

  // Set text color 
  tft.setTextColor(color);

  // Set text cursor position
  tft.setCursor(x, y);

  // Print the text
  tft.print(text);

  // Reset font to default (non-bold)
  tft.setFreeFont(0);
}

void setFontStyle(int font){
  if (font == 1){
     tft.setFreeFont(SL8);
  }
  else if (font == 2){
     tft.setFreeFont(DS10);
  }
  else if (font == 3){
     tft.setFreeFont(RS10);
  }
  else{
      tft.setFreeFont(0);
  }    
}

void decimalNumber(float sensor, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.drawFloat(sensor, 2, x, y);
}

void displayNumber(float num, int size, int x, int y, uint16_t color) {
  tft.setTextColor(color);
  tft.setTextSize(size);
  tft.drawFloat(num, 0, x, y);
}

void drawRectangle(int x, int y, int width, int height, float angle, uint16_t color) {
    // Convert angle to radians
    float rad = angle * DEG_TO_RAD;

    // Calculate the half-dimensions of the box
    float halfWidth = width / 2.0;
    float halfHeight = height / 2.0;

    // Calculate the center of the box
    float cx = x + halfWidth;
    float cy = y + halfHeight;

    // Calculate the rotated coordinates of each corner of the box
    float corners[4][2];
    corners[0][0] = -halfWidth;
    corners[0][1] = -halfHeight;
    corners[1][0] = halfWidth;
    corners[1][1] = -halfHeight;
    corners[2][0] = halfWidth;
    corners[2][1] = halfHeight;
    corners[3][0] = -halfWidth;
    corners[3][1] = halfHeight;

    for (int i = 0; i < 4; i++) {
        float xRot = corners[i][0] * cos(rad) - corners[i][1] * sin(rad);
        float yRot = corners[i][0] * sin(rad) + corners[i][1] * cos(rad);
        corners[i][0] = xRot + cx;
        corners[i][1] = yRot + cy;
    }

    // Draw the rotated box by connecting the corners
    tft.drawLine(corners[0][0], corners[0][1], corners[1][0], corners[1][1], color);
    tft.drawLine(corners[1][0], corners[1][1], corners[2][0], corners[2][1], color);
    tft.drawLine(corners[2][0], corners[2][1], corners[3][0], corners[3][1], color);
    tft.drawLine(corners[3][0], corners[3][1], corners[0][0], corners[0][1], color);
}

void fillEllipse(int16_t x, int16_t y, int32_t rx, int32_t ry, uint16_t color){
  tft.fillEllipse(x, y, rx, ry, color);
}

void fillCircle(int x, int y, int radius, uint16_t color){
  tft.fillCircle(x, y, radius, color);
}

void drawCircle(int x, int y, int radius, uint16_t color){
  tft.drawCircle(x, y, radius, color);
}

void drawEllipse(int16_t x, int16_t y, int32_t radiusx, int32_t radiusy, uint16_t color){
  tft.drawEllipse(x, y, radiusx, radiusy, color);
}

void rotatePoint(int &x, int &y, int cx, int cy, float angle) {
    // Convert angle to radians
    float rad = angle * DEG_TO_RAD;

    // Translate point to origin
    int tempX = x - cx;
    int tempY = y - cy;

    // Rotate point
    int rotatedX = tempX * cos(rad) - tempY * sin(rad);
    int rotatedY = tempX * sin(rad) + tempY * cos(rad);

    // Translate point back
    x = rotatedX + cx;
    y = rotatedY + cy;
}

void drawRightTriangle(int x, int y, int base, int height, float angle, uint16_t color) {
    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + base, y1 = y;
    int x2 = x, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawEquilateralTriangle(int x, int y, int sideLength, float angle, uint16_t color) {
    // Calculate the height of the equilateral triangle
    int height = sideLength * sqrt(3) / 2;

    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + sideLength, y1 = y;
    int x2 = x + sideLength / 2, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawIsoscelesTriangle(int x, int y, int base, int height, float angle, uint16_t color) {
    // Calculate the coordinates of each corner
    int x0 = x, y0 = y;
    int x1 = x + base, y1 = y;
    int x2 = x + base / 2, y2 = y - height;

    // Rotate each point around the origin (x, y)
    rotatePoint(x0, y0, x, y, angle);
    rotatePoint(x1, y1, x, y, angle);
    rotatePoint(x2, y2, x, y, angle);

    // Draw the rotated triangle
    tft.drawLine(x0, y0, x1, y1, color);
    tft.drawLine(x1, y1, x2, y2, color);
    tft.drawLine(x2, y2, x0, y0, color);
}

void drawButton(const char* text, int textSize, int x, int y, uint16_t btcolor, uint16_t textColor, uint16_t bgColor) {
    // Set the text size
    tft.setTextSize(textSize);
    
    // Estimate the width and height of the text
    int textWidth = strlen(text) * 6 * textSize; // Approximate width: 6 pixels per character
    int textHeight = 8 * textSize; // Approximate height: 8 pixels per character

    // Calculate button dimensions
    int padding = 10;
    int buttonWidth = textWidth + 2 * padding;
    int buttonHeight = textHeight + 2 * padding;

    // Draw the button rectangle
    tft.fillRoundRect(x, y, buttonWidth, buttonHeight, 5, btcolor);
    tft.drawRoundRect(x, y, buttonWidth, buttonHeight, 5, bgColor);

    // Calculate the coordinates to center the text
    int16_t xText = x + (buttonWidth - textWidth) / 2;
    int16_t yText = y + (buttonHeight - textHeight) / 2;

    // Set the text color and draw the text
    tft.setTextColor(textColor, btcolor);
    tft.setCursor(xText, yText);
    tft.print(text);
}

void fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, float angle, uint32_t color) {
  if (angle == 0) {
    // No rotation, draw normally
    tft.fillRect(x, y, w, h, color);
  } else {
    // Rotation needed
    float rad = angle * DEG_TO_RAD; // Convert angle to radians
    float cosA = cos(rad);
    float sinA = sin(rad);

    // Calculate coordinates of the corners
    int x0 = -w / 2;
    int y0 = -h / 2;
    int x1 = w / 2;
    int y1 = -h / 2;
    int x2 = w / 2;
    int y2 = h / 2;
    int x3 = -w / 2;
    int y3 = h / 2;

    // Rotate the corners around the center point (x, y)
    int xr0 = x + x0 * cosA - y0 * sinA;
    int yr0 = y + x0 * sinA + y0 * cosA;
    int xr1 = x + x1 * cosA - y1 * sinA;
    int yr1 = y + x1 * sinA + y1 * cosA;
    int xr2 = x + x2 * cosA - y2 * sinA;
    int yr2 = y + x2 * sinA + y2 * cosA;
    int xr3 = x + x3 * cosA - y3 * sinA;
    int yr3 = y + x3 * sinA + y3 * cosA;

    // Draw filled triangles to create the filled rectangle
    tft.fillTriangle(xr0, yr0, xr1, yr1, xr2, yr2, color);
    tft.fillTriangle(xr0, yr0, xr2, yr2, xr3, yr3, color);
  }
}
void drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color) {
  float rad = angle * DEG_TO_RAD; // Convert angle to radians
  float cosA = cos(rad);
  float sinA = sin(rad);

  int32_t cx = (x0 + x1 + x2) / 3;
  int32_t cy = (y0 + y1 + y2) / 3;

  // Translate points to origin
  int32_t tx0 = x0 - cx;
  int32_t ty0 = y0 - cy;
  int32_t tx1 = x1 - cx;
  int32_t ty1 = y1 - cy;
  int32_t tx2 = x2 - cx;
  int32_t ty2 = y2 - cy;

  // Rotate points
  int32_t rx0 = tx0 * cosA - ty0 * sinA;
  int32_t ry0 = tx0 * sinA + ty0 * cosA;
  int32_t rx1 = tx1 * cosA - ty1 * sinA;
  int32_t ry1 = tx1 * sinA + ty1 * cosA;
  int32_t rx2 = tx2 * cosA - ty2 * sinA;
  int32_t ry2 = tx2 * sinA + ty2 * cosA;

  // Translate points back
  int32_t nx0 = rx0 + cx;
  int32_t ny0 = ry0 + cy;
  int32_t nx1 = rx1 + cx;
  int32_t ny1 = ry1 + cy;
  int32_t nx2 = rx2 + cx;
  int32_t ny2 = ry2 + cy;

  // Draw the rotated triangle
  tft.drawLine(nx0, ny0, nx1, ny1, color);
  tft.drawLine(nx1, ny1, nx2, ny2, color);
  tft.drawLine(nx2, ny2, nx0, ny0, color);
}

void fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color){

  float rad = angle * DEG_TO_RAD; // Convert angle to radians
  float cosA = cos(rad);
  float sinA = sin(rad);

  int32_t cx = (x0 + x1 + x2) / 3;
  int32_t cy = (y0 + y1 + y2) / 3;

  // Translate points to origin
  int32_t tx0 = x0 - cx;
  int32_t ty0 = y0 - cy;
  int32_t tx1 = x1 - cx;
  int32_t ty1 = y1 - cy;
  int32_t tx2 = x2 - cx;
  int32_t ty2 = y2 - cy;

  // Rotate points
  int32_t rx0 = tx0 * cosA - ty0 * sinA;
  int32_t ry0 = tx0 * sinA + ty0 * cosA;
  int32_t rx1 = tx1 * cosA - ty1 * sinA;
  int32_t ry1 = tx1 * sinA + ty1 * cosA;
  int32_t rx2 = tx2 * cosA - ty2 * sinA;
  int32_t ry2 = tx2 * sinA + ty2 * cosA;

  // Translate points back
  int32_t nx0 = rx0 + cx;
  int32_t ny0 = ry0 + cy;
  int32_t nx1 = rx1 + cx;
  int32_t ny1 = ry1 + cy;
  int32_t nx2 = rx2 + cx;
  int32_t ny2 = ry2 + cy;

  // Draw the rotated triangle
  tft.fillTriangle(nx0, ny0, nx1, ny1, nx2, ny2, color);
}

struct ImagePosition {
    int16_t x;
    int16_t y;
} imagePos;

void displayImage(uint8_t *imageData, uint32_t imageSize, int16_t xpos, int16_t ypos) {
    imagePos.x = xpos;
    imagePos.y = ypos;
    
    int16_t rc = png.openFLASH(imageData, imageSize, pngDraw);
    if (rc == PNG_SUCCESS) {
        Serial.println("Successfully opened png file");
        Serial.printf("image specs: (%d x %d), %d bpp, pixel type: %d\n", png.getWidth(), png.getHeight(), png.getBpp(), png.getPixelType());
        tft.startWrite();
        uint32_t dt = millis();
        rc = png.decode(NULL, 0);
        Serial.print(millis() - dt); Serial.println("ms");
        tft.endWrite();
        // png.close(); // not needed for memory->memory decode
    }
}

void pngDraw(PNGDRAW *pDraw) {
    uint16_t lineBuffer[MAX_IMAGE_WIDTH];
    png.getLineAsRGB565(pDraw, lineBuffer, PNG_RGB565_BIG_ENDIAN, 0xffffffff);
    tft.pushImage(imagePos.x, imagePos.y + pDraw->y, pDraw->iWidth, 1, lineBuffer);
}

void startStopwatch() {
    if (!running) {
        running = true;
        startTime = millis() - elapsedTime;
    }
}

void stopStopwatch() {
    if (running) {
        running = false;
        elapsedTime = millis() - startTime;
    }
}

void resetStopwatch() {
    startTime = 0;
    elapsedTime = 0;
    running = false;
    displayStopwatchTime();
}

void updateStopwatch() {
    if (running) {
        elapsedTime = millis() - startTime;
        displayStopwatchTime();
    }
}

void displayStopwatchTime() {
    int seconds = (elapsedTime / 1000) % 60;
    int minutes = (elapsedTime / (1000 * 60)) % 60;
    int hours = (elapsedTime / (1000 * 60 * 60)) % 24;
    sprintf(timeString, "%02d:%02d:%02d", hours, minutes, seconds);
    tft.fillRect(18, 78, 202, 65, TFT_YELLOW); // Drawing stopwatch area with light yellow color
    displayMessage(timeString, 3, 50, 100, TFT_BLACK);
}

bool isStopwatchRunning() {
    return running;
}

  void drawLoading() {
    int x0 = 300;
    int y0 = 60;
    int x1 = 280;
    int y1 = 60;

    for (int i = 0; i < 14; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      x0 = x1;
      x1 = x0 - 20;
      delay(100);
    }
  }

  void drawLoading1() {
    drawLoading();
    int x0 = 20;
    int y0 = 60;
    int x1 = 20;
    int y1 = 80;

    for (int i = 0; i < 9; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      y0 = y1;
      y1 = y0 + 10;
      delay(100);
    }
  }

  void drawLoading2() {
    drawLoading1();
    int x0 = 20;
    int y0 = 160;
    int x1 = 40;
    int y1 = 160;

    for (int i = 0; i < 14; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      x0 = x1;
      x1 = x0 + 20;
      delay(100);
    }
  }

  void drawLoading3() {
    drawLoading2();
    int x0 = 300;
    int y0 = 160;
    int x1 = 300;
    int y1 = 150;

    for (int i = 0; i < 10; i++) {
      tft.drawLine(x0, y0, x1, y1, TFT_WHITE);
      y0 = y1;
      y1 = y0 - 10;
      delay(100);
    }
  }
  
  void loadingAnimation(){
    drawLoading3();
  }

//======================================================================================
//--------------------------------End Display-------------------------------------------
//======================================================================================

//======================================================================================
//-----------------------------------Touch----------------------------------------------
//======================================================================================

void initializeTouch() {
    ft6336u.begin();
}

void readTouch() {
    tp = ft6336u.scan(); // Scan for touch input
    uint8_t firmware_id = ft6336u.read_firmware_id(); 
    int original_x = tp.tp[0].x;
    int original_y = tp.tp[0].y;
    x = 0;
    y = 0;
    touched = ft6336u.read_td_status();       // Read touch status
    // Menyesuaikan koordinat berdasarkan firmware ID
    if (firmware_id == 0x11) {
        // Firmware ID 0x11 (koordinat (0, 0) di kiri bawah)
        x = original_x;
        y = original_y;
    } else if (firmware_id == 0x4 || firmware_id == 0x44) {
        // Firmware ID 0x4 atau 0x44 (koordinat (0, 0) di kiri atas)
        int screenWidth = 240;  // Lebar layar
        int screenHeight = 320; // Tinggi layar

        // Transformasi koordinat
        x = screenWidth - 1 - map(original_x, 0, screenWidth - 1, 0, screenWidth - 1);
        y = screenHeight - 1 - map(original_y, 0, screenHeight - 1, 0, screenHeight - 1);

        // Pastikan nilai tetap dalam batas layar
        if (x < 0) x = 0;
        if (x > tft.height()) x = tft.height();
        if (y < 0) y = 0;
        if (y > tft.width()) y = tft.width();
    }
        // Tampilkan hasil koordinat yang disesuaikan
        char tempString[128];
        sprintf(tempString, "Firmware ID: 0x%x, TD1 (%d, %4d, %4d)\r", firmware_id, tp.tp[0].status, x, y);
        Serial.println(tempString);    
}

bool areaTouch(int x1, int x2, int y1, int y2) {
    return (x > x1 && x < x2 && y > y1 && y < y2);
}

  void plotLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint32_t color) 
  {
    // Calculate differences and signs for incremental steps
    int16_t dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int16_t dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int16_t err = dx + dy, e2; /* error value e_xy */

    // Loop through all points between the start and end coordinates
    while (true) 
    {
      // Draw a point at the current coordinates
      tft.fillCircle(x0, y0, PEN_SIZE, color); 

      // Check if the end point is reached
      if (x0 == x1 && y0 == y1) break;

      // Calculate error values for next point
      e2 = 2 * err;

      // Adjust x coordinate and error value if needed
      if (e2 >= dy) { err += dy; x0 += sx; }

      // Adjust y coordinate and error value if needed
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }
  
void draw() {
  tp = ft6336u.scan(); 
  if (tp.tp[0].status == 1) {
    // int16_t x = tp.tp[0].x, y = tp.tp[0].y;

    switch (tft.getRotation()) {
      case 0:
        break;  // Tidak perlu penyesuaian untuk rotasi 0
      case 1:
        std::swap(x, y);
        y = tft.height() - y;
        break;
      case 2:
        x = tft.width() - x;
        y = tft.height() - y;
        break;
      case 3:
        std::swap(x, y);
        x = tft.width() - x;
        break;
    }

    if (prevX != -1 && prevY != -1) {
      plotLine(prevX, prevY, x, y, TFT_RED);
    }
    prevX = x;
    prevY = y;
  } else {
    prevX = -1;
    prevY = -1;
  }
}

// void draw() {
//   tp = ft6336u.scan(); 
//   if (tp.tp[0].status == 1) {
//     int16_t x = tp.tp[0].x;
//     int16_t y = tp.tp[0].y;
//     switch (tft.getRotation()) {
//       case 2:
//         break;
//       case 1: {
//         int16_t temp = x;
//         x =  tft.width() - y;
//         y = temp;
//         break;
//       }
//       case 0: {
//         x = tft.width() - x;
//         y = tft.height() - y;
//         break;
//       }
//       case 3: {
//         int16_t temp = x;
//         x = y;
//         y = tft.height() - temp;
//         break;
//       }
//     }
//     if (prevX != -1 && prevY != -1) {
//       plotLine(prevX, prevY, x, y, TFT_RED);
//     }
//     prevX = x;
//     prevY = y;
//   } else {
//     prevX = -1;
//     prevY = -1;
//   }
// }

//======================================================================================
//---------------------------------End Touch--------------------------------------------
//======================================================================================