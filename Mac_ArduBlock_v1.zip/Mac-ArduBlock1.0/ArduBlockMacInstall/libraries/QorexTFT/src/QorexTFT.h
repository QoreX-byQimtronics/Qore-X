#pragma once
#ifndef QOREXTFT_H
#define QOREXTFT_H

#include <TFT_eSPI.h>
#include "Free_Fonts.h" 
#include <FT6336U.h>
#include <PNGdec.h>   

// extern TFT_eSPI tft;
extern FT6336U ft6336u;
extern uint16_t x, y, touched;
// extern int touchCounter;
//======================================================================================
//---------------------------------Display----------------------------------------------
//======================================================================================
void initDisplay(int rotation, uint16_t fillColor);
void fillScreen( uint16_t color);
void displayMessage(const char* message, int size, int x, int y, uint16_t color);
void displayMessageBold(const char* text, int size, int x, int y, uint32_t color);
void displayMessageItalic(const char* text, int size, int x, int y, uint32_t color);
void setFontStyle(int font);
void decimalNumber(float sensor, int size, int x, int y, uint16_t color);
void displayNumber(float num, int size, int x, int y, uint16_t color);
void drawRectangle(int x, int y, int width, int height, float angle, uint16_t color);  
void fillEllipse(int16_t x, int16_t y, int32_t rx, int32_t ry, uint16_t color);
void fillCircle(int x, int y, int radius, uint16_t color);
void drawCircle(int x, int y, int radius, uint16_t color);
void drawRightTriangle(int x, int y, int base, int height, float angle, uint16_t color);
void drawEquilateralTriangle(int x, int y, int sideLength, float angle, uint16_t color);
void drawIsoscelesTriangle(int x, int y, int base, int height, float angle, uint16_t color);
void drawEllipse(int16_t x, int16_t y, int32_t radiusx, int32_t radiusy, uint16_t color);
void drawButton(const char* text, int textSize, int x, int y, uint16_t btcolor, uint16_t textColor, uint16_t bgColor);
void fillRectangle(int32_t x, int32_t y, int32_t w, int32_t h, float angle, uint32_t color);
void drawTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color);
void fillTriangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2, float angle, uint32_t color);
void displayImage(uint8_t *imageData, uint32_t imageSize, int16_t xpos, int16_t ypos);
void pngDraw(PNGDRAW *pDraw);
void startStopwatch();
void stopStopwatch();
void resetStopwatch();
void updateStopwatch();
void displayStopwatchTime();
bool isStopwatchRunning();
void pauseStopwatch();
void loadingAnimation();
//======================================================================================
//--------------------------------End Display-------------------------------------------
//======================================================================================

//======================================================================================
//-----------------------------------Touch----------------------------------------------
//======================================================================================
void initializeTouch();
void readTouch();
bool areaTouch(int x1, int x2, int y1, int y2);
void draw();
//======================================================================================
//---------------------------------End Touch--------------------------------------------
//======================================================================================

#endif