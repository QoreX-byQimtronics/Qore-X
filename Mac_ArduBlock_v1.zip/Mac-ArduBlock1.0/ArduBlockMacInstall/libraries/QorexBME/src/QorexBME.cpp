#include "QorexBME.h"

Adafruit_BME280 bme;


//======================================================================================
//-------------------------------------BME----------------------------------------------
//======================================================================================
void initBME() {
  int statusBme = bme.begin(0x76); 
  if (!statusBme) {
    Serial.println("Could not find a valid BME 280 sensor, check wiring!");
    while (1);
  }
}

float bmeTemperature() {
  return bme.readTemperature();
}

float bmePressure() {
  return bme.readPressure();
}

float bmeAltitude(float seaLevelPressure) {
  return bme.readAltitude(seaLevelPressure);
}

float bmeHumidity(){
  return bme.readHumidity();
}

// void weatherPrediction(float pressure, float prevPressure, float temperature, float humidity, int x, int y) {
//     tft.fillRect(x, y, 240, 50, TFT_BLACK);  // Clear the previous prediction
//     tft.setCursor(x, y);

//     String prediction = "Weather: ";
    
//     // Basic pressure trend prediction
//     if (pressure > prevPressure + 0.1) {
//         prediction += "Better";
//         tft.setTextColor(TFT_GREEN);
//     } else if (pressure < prevPressure - 0.1) {
//         prediction += "Worse";
//         tft.setTextColor(TFT_RED);
//     } else {
//         prediction += "Stable";
//         tft.setTextColor(TFT_WHITE);
//     }

//     tft.println(prediction);

//     // Additional hints based on temperature and humidity
//     tft.setCursor(0, 170);
//     if (humidity > 80) {
//         tft.println("High Humidity: Possible rain");
//     } else if (temperature > 30) {
//         tft.println("High Temp: Hot weather");
//     } else if (temperature < 0) {
//         tft.println("Low Temp: Cold weather");
//     } else {
//         tft.println("Temp and Humidity Normal");
//     }
// }
//======================================================================================
//------------------------------------End BME-------------------------------------------
//======================================================================================