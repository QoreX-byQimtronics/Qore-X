#ifndef QOREXBME_H
#define QOREXBME_H

#include <Adafruit_BME280.h>  

//======================================================================================
//-------------------------------------BME----------------------------------------------
//======================================================================================
void initBME();
float bmeTemperature();
float bmePressure();
float bmeAltitude(float seaLevelPressure);
float bmeHumidity();
void weatherPrediction(float pressure, float prevPressure, float temperature, float humidity, int x, int y);
//======================================================================================
//------------------------------------End BME-------------------------------------------
//======================================================================================

#endif