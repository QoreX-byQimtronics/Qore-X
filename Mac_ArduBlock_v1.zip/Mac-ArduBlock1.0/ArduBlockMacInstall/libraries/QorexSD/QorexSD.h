
#ifndef QOREXSD_H
#define QOREXSD_H

#include "FS.h"
#include "SD.h"
#include "SPI.h"

// extern uint8_t levels;

void initSDCard();
void createDir(fs::FS &fs, const char * path);
void listDir(fs::FS &fs, const char * dirname, uint8_t levels);
void removeDir(fs::FS &fs, const char * path);
void readFile(fs::FS &fs, const char * path);
void writeFile(fs::FS &fs, const char * path, const char * message);
void appendFile(fs::FS &fs, const char * path, const char * message);
void deleteFile(fs::FS &fs, const char * path);

#endif