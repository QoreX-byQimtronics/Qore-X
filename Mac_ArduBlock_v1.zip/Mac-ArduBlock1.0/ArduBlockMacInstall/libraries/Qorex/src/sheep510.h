// horse_data.h
#ifndef SHEEP510_H
#define SHEEP510_H

extern unsigned char sheep510[];

#endif // SHEEP_H
