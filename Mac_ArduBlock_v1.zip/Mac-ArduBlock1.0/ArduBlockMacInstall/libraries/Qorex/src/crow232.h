// horse_data.h
#ifndef CROW232_H
#define CROW232_H

extern unsigned char crow232[];

#endif // CROW_H
