// horse_data.h
#ifndef CAT827_H
#define CAT827_H

extern unsigned char cat827[];

#endif // CAT_H
