// horse_data.h
#ifndef DUCK034_H
#define DUCK034_H

extern unsigned char duck034[];

#endif // DUCK_H
