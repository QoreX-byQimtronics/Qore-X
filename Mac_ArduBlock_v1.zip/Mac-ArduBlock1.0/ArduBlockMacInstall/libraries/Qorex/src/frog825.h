// horse_data.h
#ifndef FROG825_H
#define FROG825_H

extern unsigned char frog825[];

#endif // FROG_H
