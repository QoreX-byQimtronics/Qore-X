// horse_data.h
#ifndef ROOSTER382_H
#define ROOSTER382_H

extern unsigned char rooster382[];

#endif // ROOSTER_H
