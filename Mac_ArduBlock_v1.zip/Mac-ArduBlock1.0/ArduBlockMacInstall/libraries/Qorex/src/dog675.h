// horse_data.h
#ifndef DOG675_H
#define DOG675_H

extern unsigned char dog675[];

#endif // DOG_H
