// horse_data.h
#ifndef ELEPHANT725_H
#define ELEPHANT725_H

extern unsigned char elephant725[];

#endif // ELEPHANT_H
