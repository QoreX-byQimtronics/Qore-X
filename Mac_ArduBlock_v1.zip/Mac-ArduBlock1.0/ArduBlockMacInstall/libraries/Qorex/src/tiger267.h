// horse_data.h
#ifndef TIGER267_H
#define TIGER267_H

extern unsigned char tiger267[];

#endif // TIGER_H
