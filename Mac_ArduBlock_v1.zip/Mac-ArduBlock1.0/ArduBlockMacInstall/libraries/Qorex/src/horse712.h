// horse_data.h
#ifndef HORSE712_H
#define HORSE712_H

extern unsigned char horse712[];

#endif // HORSE_DATA_H
