
#ifndef QOREXBT_H
#define QOREXBT_H

#include <BluetoothSerial.h>

extern BluetoothSerial SerialBT;

/*
======================================================================================
---------------------------------BLUETOOTH--------------------------------------------
======================================================================================
*/
void initBT(const char* deviceName);
void btScan();
bool btConnected();
void btStatus();

#endif