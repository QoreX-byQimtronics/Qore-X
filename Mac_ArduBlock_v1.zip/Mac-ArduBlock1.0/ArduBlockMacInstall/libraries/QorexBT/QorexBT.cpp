#include "QorexBT.h"

BluetoothSerial SerialBT;

/*
======================================================================================
---------------------------------BLUETOOTH--------------------------------------------
======================================================================================
*/
void initBT(const char* deviceName) {
  Serial.begin(115200);
  SerialBT.begin(deviceName);

  #if defined (USE_TFT)
    #define USE_TFT
    tft.init();
    tft.setRotation(3);
    tft.setTextColor(TFT_WHITE);
    tft.fillScreen(TFT_BLACK);
    Serial.println("TFT initialized.");
  #endif
}

void btAdvertisedDeviceFound(BTAdvertisedDevice* pDevice) {
  Serial.printf("Found a device asynchronously: %s\n", pDevice->toString().c_str());
}

// Fungsi untuk melakukan scan perangkat Bluetooth
void btScan() {
  // Contoh: jalankan scan asinkron terlebih dahulu
  Serial.print("Starting discoverAsync...");
  if (SerialBT.discoverAsync(btAdvertisedDeviceFound)) {
    Serial.println("Findings will be reported in \"btAdvertisedDeviceFound\"");
    delay(10000);  // Lakukan delay untuk memberikan waktu scanning
    Serial.print("Stopping discoverAsync... ");
    SerialBT.discoverAsyncStop();  // Hentikan scanning asinkron
    Serial.println("stopped");
  } else {
    Serial.println("Error on discoverAsync, for example, not working after a \"connect\"");
  }

  // Lanjutkan dengan scan sinkron setelah scan asinkron selesai
  Serial.println("Starting discover...");
  BTScanResults* pResults = SerialBT.discover(10);  // Durasi scan (10 detik dalam contoh ini)
  if (pResults) {
    pResults->dump(&Serial);  // Tampilkan hasil scan
  } else {
    Serial.println("BT Scan, no result!");
  }
  delay(5000);
}

bool btConnected() {
  return SerialBT.connected();
}

void btStatus(){
  bool wasConnected = false;

  if (SerialBT.connected() && !wasConnected) {
    Serial.println("Bluetooth device connected successfully.");
    wasConnected = true;
  } 
  else if (!SerialBT.connected() && !wasConnected) {
    Serial.println("Waiting For Bt Connection");
  }  
}
